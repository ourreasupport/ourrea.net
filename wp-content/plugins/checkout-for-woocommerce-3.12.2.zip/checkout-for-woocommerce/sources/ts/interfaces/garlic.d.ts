interface JQuery {
    garlic: any;
}
