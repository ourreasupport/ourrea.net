interface JQuery {
    firstOn: any;
}
