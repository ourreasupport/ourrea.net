<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Glass Theme Init
 *
 * Add things that should happen on theme activation here.
 *
 * Default settings are initted in Template
 */

