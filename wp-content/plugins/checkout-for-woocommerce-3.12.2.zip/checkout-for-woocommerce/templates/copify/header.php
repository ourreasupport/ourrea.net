<?php
/**
 * For Copify, the header is defined in content.php for layout purposes
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
